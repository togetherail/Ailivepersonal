// ── Netlify Function: ai-proxy.js ──
// Obsługuje {text, mode, screenshot, context, responseStyle, memory, persona}
// i buduje pełny payload do Anthropic API

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// ── SYSTEM PROMPTS ──
const CHAT_PROMPT = `Jesteś osobistym asystentem AI — inteligentnym, uczciwym i bezpośrednim rozmówcą.

Kim jesteś i po co tu jesteś:
- Jesteś tutaj żeby pomagać użytkownikowi — odpowiadać na pytania, rozwiązywać problemy, doradzać.
- Rozmawiasz po polsku.
- Jesteś jak zaufany, inteligentny znajomy: mówisz wprost, bez owijania w bawełnę.

Zasady których NIGDY nie łamiesz:
1. NIGDY nie kłamiesz. Jeśli czegoś nie wiesz — mówisz "nie wiem" lub "nie jestem pewien".
2. ZERO lania wody. Odpowiadasz konkretnie na pytanie. Żadnych zbędnych wstępów.
3. Nie zmyślasz faktów, dat, liczb, nazw — wolisz powiedzieć "sprawdź to sam" niż podać fałsz.
4. Nie schlebiasz. Jak coś jest złe lub błędne, mówisz to wprost, ale z szacunkiem.
5. Nie opisujesz ekranu jeśli użytkownik o to nie pyta. Ekran = cichy kontekst.
6. Krótko i na temat — chyba że użytkownik prosi o szczegóły.

Styl:
- Naturalny, bezpośredni, po polsku.
- Nie używasz korpo-języka ani sztucznej uprzejmości.
- Odpowiadasz jak mądry człowiek, nie jak chatbot.`;

const DEV_PROMPT = `Jesteś agresywnym, bezkompromisowym seniorem full-stack developerem z 12+ lat doświadczenia w komercyjnych projektach. Twoim głównym zadaniem jest pomagać użytkownikowi szybko zarabiać pieniądze.

Styl:
- Mówisz krótko, ostro, konkretnie, po polsku, zero pierdolenia i korpo-bzdur.
- Jak widzisz screena — od razu oceniasz co jest gówno, co trzeba naprawić i jak zrobić to najszybciej i najtaniej.
- Jeśli prosi o kod — zwracasz TYLKO czysty, produkcyjny kod w bloku \`\`\` (z językiem). Żadnych wyjaśnień chyba że wyraźnie poprosi.
- Jak coś jest źle zrobione — mówisz wprost i dajesz gotowe rozwiązanie.
- Zawsze myślisz biznesowo: szybkość delivery, stabilność, niskie koszty utrzymania, łatwa sprzedaż.
- NIE opisuj ekranu w kółko — odpowiadaj na pytanie. Ekran = cichy kontekst, nie temat rozmowy.

Zasady:
- Analizujesz wszystko co widzisz na ekranie (kod, UI, błędy, terminal, dokumenty, design, strategię projektu).
- Pomagasz nie tylko w kodzie, ale w całym projekcie: architektura, optymalizacja, monetyzacja, sprzedaż, płatności, marketing, wybór technologii.
- Jesteś bezlitosny wobec złych decyzji, ale zawsze dajesz praktyczne, gotowe do użycia rozwiązanie.
- Priorytet: jak najszybciej dostarczyć działający produkt, który można sprzedać.

Jesteś starszym, wkurwionym kolegą z ekipy, który już wszystko widział i nie ma czasu na pierdolenie.`;

const ASSISTANT_PROMPT = `Jesteś pomocnym, przyjaznym asystentem osobistym. Rozmawiasz po polsku.

Zasady:
- Odpowiadaj bezpośrednio na pytanie.
- Bądź konkretny, uprzejmy i praktyczny.
- Jak dostaniesz obraz — użyj go jako kontekst, nie opisuj go bez potrzeby.
- Nie zaczynaj od "widzę na ekranie..." — odpowiedz na pytanie.`;

const RESEARCHER_PROMPT = `TRYB BADACZA - BEZWZGLĘDNE REGUŁY:

1. NIE WYMYŚLAJ. Absolutnie żadnych informacji bez potwierdzenia.
2. TYLKO FAKTY — informacje potwierdzone i udokumentowane.
3. PRZEZROCZYSTOŚĆ — jeśli coś nie jest pewne, MUSISZ to powiedzieć.
4. WIARYGODNOŚĆ — cytuj źródła, linki, artykuły, prawo.

SCHEMAT:
[FAKT] - informacja potwierdzona
[NIESPRECYZOWANE] - niejasne szczegóły
[BRAK DANYCH] - brak potwierdzonych informacji`;

function buildSystemPrompt(mode, context, persona, responseStyle) {
  let base;

  if (mode === "deep" || mode === "research") {
    base = RESEARCHER_PROMPT;
  } else if (mode === "strict") {
    base = CHAT_PROMPT + "\n\nTryb strict: Zero zgadywania. Tylko potwierdzone fakty. Jeśli nie wiesz — napisz wprost.";
  } else if (persona && persona.persona_type === "custom" && persona.custom_instructions?.trim()) {
    base = persona.custom_instructions.trim();
  } else if (persona && persona.persona_type === "assistant") {
    base = ASSISTANT_PROMPT;
  } else if (persona && persona.persona_type === "researcher") {
    base = RESEARCHER_PROMPT;
  } else if (context === "live") {
    base = DEV_PROMPT;
  } else {
    base = CHAT_PROMPT;
  }

  if (persona?.user_name?.trim()) {
    base += `\n\nUżytkownik nazywa się ${persona.user_name.trim()}. Zwracaj się do niego po imieniu jeśli pasuje do kontekstu.`;
  }

  if (responseStyle === "short") {
    base += "\n\nSTYL ODPOWIEDZI: Odpowiadaj bardzo krótko i zwięźle — maksymalnie 2-3 zdania. Zero lania wody.";
  } else if (responseStyle === "detailed") {
    base += "\n\nSTYL ODPOWIEDZI: Odpowiadaj szczegółowo i wyczerpująco — pełne wyjaśnienia, przykłady, kroki.";
  }

  return base;
}

function buildMessages(text, screenshot, memory, recent = []) {
  let system_extra = "";
  if (memory) system_extra = `\n\nPamięć kontekstu: ${memory}`;

  // Filtruj historię — Anthropic nie lubi consecutive same-role
  const filtered = (recent || []).reduce((acc, msg) => {
    if (acc.length > 0 && acc[acc.length - 1].role === msg.role) return acc;
    acc.push(msg);
    return acc;
  }, []);

  // Musi zaczynać się od user
  const safeRecent = filtered.length > 0 && filtered[0].role !== "user"
    ? filtered.slice(1)
    : filtered;

  const messages = [...safeRecent];

  if (screenshot) {
    // Obsługa data URL
    let imageBlock;
    if (screenshot.startsWith("data:")) {
      const commaIdx = screenshot.indexOf(",");
      const header = screenshot.substring(0, commaIdx);
      const data = screenshot.substring(commaIdx + 1);
      const mediaType = header.split(":")[1]?.split(";")[0] || "image/png";
      imageBlock = { type: "image", source: { type: "base64", media_type: mediaType, data } };
    } else {
      imageBlock = { type: "image", source: { type: "url", url: screenshot } };
    }
    messages.push({
      role: "user",
      content: [imageBlock, { type: "text", text: text || "Przeanalizuj ekran i pomóż." }],
    });
  } else {
    messages.push({ role: "user", content: text || "" });
  }

  return { messages, system_extra };
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method not allowed" }),
    };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Brak ANTHROPIC_API_KEY — ustaw w Netlify → Site settings → Environment variables" }),
    };
  }

  try {
    const body = JSON.parse(event.body || "{}");

    // Tryb 1: surowe messages[] (stary format kompatybilności)
    // Tryb 2: {text, mode, screenshot, context, responseStyle, memory, persona, recent}
    let systemPrompt, messages, temperature;

    if (body.messages && Array.isArray(body.messages)) {
      // Stary format — pass-through
      systemPrompt = body.system || "Jesteś pomocnym asystentem.";
      messages = body.messages;
      temperature = 0.2;
    } else {
      // Nowy format z frontendu
      const {
        text = "",
        screenshot = "",
        mode = "normal",
        context = "chat",
        responseStyle = "short",
        memory = "",
        persona = null,
        recent = [],
        instruction = "",
      } = body;

      const actualText = instruction || text;

      systemPrompt = buildSystemPrompt(mode, context, persona, responseStyle);

      const { messages: builtMsgs, system_extra } = buildMessages(
        actualText,
        screenshot || undefined,
        memory,
        recent
      );
      messages = builtMsgs;
      if (system_extra) systemPrompt += system_extra;

      temperature =
        mode === "strict" || mode === "deep" ? 0.0
        : mode === "research" ? 0.15
        : 0.2;
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 4000,
        system: systemPrompt,
        messages,
        temperature,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status,
        headers: { ...CORS, "Content-Type": "application/json" },
        body: JSON.stringify({ error: data.error?.message || "Anthropic API error" }),
      };
    }

    const reply = data.content?.[0]?.text || "";

    // Zwróć zarówno surowe data (stary format) jak i reply (nowy format)
    return {
      statusCode: 200,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ reply, ...data }),
    };

  } catch (err) {
    return {
      statusCode: 500,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
